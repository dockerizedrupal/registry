
# Drivers

* [docker-registry-driver-elliptics](https://github.com/noxiouz/docker-registry-driver-elliptics)
* [docker-registry-driver-swift](https://github.com/bacongobbler/docker-registry-driver-swift)
* [docker-registry-driver-qiniu](https://github.com/zhangpeihao/docker-registry-driver-qiniu)
* [docker-registry-driver-hdfs](https://github.com/lyda/docker-registry-driver-hdfs)
* [docker-registry-driver-sinastorage](https://github.com/kerwin/docker-registry-driver-sinastorage)
* [docker-registry-driver-oss](https://github.com/chris-jin/docker-registry-driver-alioss.git)
* [docker-registry-driver-jss](https://github.com/zhangwei1234/docker-retistry-driver-jss.git)

